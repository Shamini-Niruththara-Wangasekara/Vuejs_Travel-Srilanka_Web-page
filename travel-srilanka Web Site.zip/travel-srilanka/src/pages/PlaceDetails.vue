<template>
<div style="margin-top: 100px">
  <div v-if="place" class="text-center">
    <img width="100%" :src="place.cover">

    <div class="container">
      <div class="row">
        <div class="col">
          <h1 >
            {{place.name}}
          </h1>
        </div>
      </div>
      <div class="row mt-5">
        <div class="col">
          <h3>
            Gallery
          </h3>
        </div>
      </div>
      <div class="row mt-5" >
        <div class="col" v-for="img in place.images">
          <div>
            <img :src="img.url" width="100%">
          </div>
        </div>
      </div>
      <div class="row mt-5">
        <div class="col" v-if="place.description && place.description.length>0">
          <h3>
            Description
          </h3>
          <p v-if="place.description">
            {{place.description}}
          </p>
        </div>
      </div>
    </div>

  </div>
  <div v-else>
    <div v-if="loading">
      Loading...
    </div>
    <div v-else>
      <div v-if="error">
        Error: {{error}}
      </div>
    </div>

  </div>

</div>
</template>

<script>
import {PlaceData} from "../components/DataSet/dataSet";

export default {
  name: "PlaceDetails",
  data() {
    return {
      place: null,
      loading: true,
      error: null,
    };
  },
  mounted() {
    const id = this.$route.params.id;
    console.log(id);
    this.place = PlaceData.find(place => place.id.toString().trim() === id.toString().trim());

  }

  }
</script>

<style scoped>

</style>

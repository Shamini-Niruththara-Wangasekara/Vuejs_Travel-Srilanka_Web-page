<template>
<div >
  <SlideShow/>
  <div class="container-fluid" style="z-index: 999;">
    <div class="row"><br><br>
     <h2>Introduction of Tourism</h2>
      <p class= "intro">Tourism is a social, cultural and 
        economic phenomenon which entails the movement of people 
        to countries or places outside their usual environment for
        personal or business/professional purposes. These people 
        are called visitors (which may be either tourists or 
        excursionists; residents or non-residents) and tourism 
        has to do with their activities, some of which imply tourism expenditure.</p>
      <p>Tourism is about a npm run devtemporary or short-term movement away from
        the place where a person normally lives and works. The tourist
        intends to return home at the end of the visit. The length of the
        visit may be from just one night up to one year. Most tourist trips
        are taken as holidays lasting one or two weeks but many business
        trips last only one night and gap year students might be travelling
        for several months.</p><p>
        Tourism usually, but not always, involves staying away from home.
        People travelling outside of their home area are called day visitors
        who are taking part in excursions.</p>
      

      <div class="col-4">
        <Map v-on:map-clicked="onMapClick" v-bind:discrict="selectedDistrict"/>
      </div>
      <div class="col offset-1">
        <PlaceList v-bind:district="selectedDistrict"/>
      </div>
    </div>

  </div>
</div>
</template>

<script>
import SlideShow from "../components/slide-show/slide-show";
import PlaceList from "../components/PlaceList/PlaceList";
import Map from "../components/Map/Map";
export default {
  name: "HomePage",
  components:{
    SlideShow,
    PlaceList,Map
  },
  data(){
    return{
      selectedDistrict:null,
    }
  },
  methods: {
    onMapClick: function(attr){
      this.selectedDistrict = attr.mapId;
    }
  }
}
</script>

<style scoped>

</style>

<template>
<div class="container">
 <div class="row" style="margin-top: 100px">
   <div class="col">
     <to-do v-bind:todos="todos" v-on:addTodo ="addNewTodo" v-on:markAsCompleted="markAsComplete"/>
   </div>
 </div>
</div>
</template>

<script>
import ToDo from "../components/todo/to-do";
export default {
  name: "ToDO",
  components: {
    ToDo
  },
  data () {
    return {
      todos: []
    }
  },
  methods: {
    addNewTodo (title, description) {
      console.log(title)
      console.log(description)
      this.todos.push({
        id: this.todos.length + 1,
        title: title,
        completed: false,
        description: description
      })
    },
    removeTodo (id) {
      this.todos = this.todos.filter(todo => todo.id !== id)
    },
    markAsComplete (id) {
      this.todos = this.todos.map(todo => {
        if (todo.id === id) {
          todo.completed = !todo.completed
        }
        return todo
      })
    }
  }
}
</script>

<style scoped>

</style>

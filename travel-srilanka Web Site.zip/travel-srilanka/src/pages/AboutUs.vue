<template>
<div class="container">
  <div class="row" style="margin-top: 100px">
    <div class="col">
      <h1>About Us</h1>
      <p>
        Travel-Sri Lanka make your life easier!!Travel-Sri lanka gives immersive
        travel storiesto passionate readers who want to learn about Sri Lanka and 
        plan their tour in Sri lanka as much as they want to travel there. Our aim
        to provide a cure by celebrating the people, places and cultures that make 
        Sri Lanka so wonderfull. Sri Lanka has been a popular place of attraction for
        travelers.Currently Sri Lanka Tourism Development Authority has classified 
        Sri Lanka into several resort regions suitable for tourism development.
      </p>
      
     <button onclick="alert('Hello\nHow are you?')">Hello</button>
     <button onclick="alert('You are browsing travel deatails of Pearl of Indian Ocean!')">Click Me</button>


    </div>
    <div class="col">
      <img width="100%" :src="travelClip">
    </div>

  </div>

</div>
</template>

<script>
import travelClip from '../assets/pngaaa.com-1861590.png'
export default {
  name: "AboutUs",
  data() {
    return {
      travelClip: travelClip
    }
  }
}
</script>

<style scoped>

</style>

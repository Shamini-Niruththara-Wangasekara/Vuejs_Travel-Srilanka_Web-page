<template>
<div>
  <div>
    <div>
      <h1>General Information</h1>
      <p>
        <b>Why Sri Lanka is famous for tourism?</b>
        The tropical climate, beautiful beaches and incredible 
        food of Sri Lanka are just some of the many reasons to 
        include the South Asian country on your travel wish list. 
        Sri Lanka is a great place to visit for water sport and wildlife 
        enthusiasts and a haven for history buffs.
      </p>
      <p><b>What type of tourism is Sri Lanka?</b>
        Domestic tourism
        The main purposes of travel by the domestic 
        tourists are pilgrimage, family holiday, study works, 
        and sightseeing. The main destinations of domestic 
        tourists are Anuradhapura, Kataragama, Nuwara Eliya,
        Kandy, Sri Pada, Polonnaruwa, Sigiriya and Dambulla.
      </p>
      <p><b>How is tourism in Sri Lanka now?</b>
       Sri Lanka recorded over 1.9 million tourist arrivals in 2019, 
       a 21 percent drop from the previous year owing to the aftermath 
       of the April 2019 Easter Terror Attacks. It is estimated that 
       the sector earned around $3.5 billion in 2019. 
       Approximately 570,000 tourists arrived in 2020.</p>



    </div>
  </div>
</div> 
</template>

<script>
    export default {
      name: "Touristinformation"
    }
</script>
<style scoped>

    
</style>
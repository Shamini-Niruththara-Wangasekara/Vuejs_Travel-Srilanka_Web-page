<template>
<div class="container" >
  <div class="row justify-content-center" style="margin-top: 150px">
    <div class="col-auto">
      <h1>Contact Us</h1>

    </div>
  </div>
  <div class="row mt-5">
    <div class="col card p-4 contact-card">
      <form>
        <div class="form-group mt-5">
          <label for="exampleFormControlInput1">Email address</label>
          <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
        </div>

        <div class="form-group mt-5">
          <label for="exampleFormControlTextarea1">Message</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>
        <div class="form-group mt-5">
          <input type="submit" class="btn btn-primary" value="Send Message">
        </div>
      </form>

    </div>
  </div>

</div>


</template>


<script>
export default {
  name: "ContactUs"
}
</script>

<style scoped>
.contact-card{
  box-shadow:  0 0 10px 0px rgba(29, 53, 72, 1);
}
</style>

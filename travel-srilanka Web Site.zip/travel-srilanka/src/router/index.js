import Vue from 'vue'
import Router from 'vue-router'
import Home from '../pages/HomePage'
import ToDO from "../pages/ToDO";
import ContactUs from "../pages/ContactUs";
import AboutUs from "../pages/AboutUs";
import PlaceDetails from "../pages/PlaceDetails";
import Touristinformation from "../pages/Touristinformation";

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'hello',
      component: Home
    },
    {
      path: '/contact',
      name: 'ContactUs',
      component: ContactUs
    },
    {
      path: '/todo',
      name: 'TO DO',
      component: ToDO
    },
    {
      path: '/about',
      name: 'About us',
      component: AboutUs
    },
    {
      path: '/place/:id',
      name: 'Place Details',
      component: PlaceDetails
    },
    {
      path: '/touristinfomation',
      name: 'Tourist Information',
      component: Touristinformation
    }
  ]
})

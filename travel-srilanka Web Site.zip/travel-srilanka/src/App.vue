<template>
  <div id="app">
    <NavBar/>
      <div style=" min-height: 65vh">
        <router-view/>
      </div>
    <Footer/>
  </div>
</template>

<script>
import NavBar from "./components/nav-bar/nav-bar";
import Footer from "./components/footer/Footer";
export default {
  name: 'App',
  components: {
    NavBar,
    Footer
  }
}
</script>

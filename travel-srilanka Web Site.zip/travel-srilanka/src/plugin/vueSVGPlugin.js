import svgjs from "svg.js/dist/svg";

export default {
  install(Vue, options) {
    Vue.prototype.$svg = svgjs;
  }
};

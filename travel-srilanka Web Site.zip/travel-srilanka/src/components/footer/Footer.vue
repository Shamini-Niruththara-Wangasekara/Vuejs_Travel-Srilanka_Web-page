<template>
<div>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>About</h3>
                    <p>
                        Find travel ideas for planning your holiday to Sri Lanka. Discover 
                        things to see and do, places to stay and more..tourism, the act and 
                        process of spending time away from home in pursuit of recreation, 
                        relaxation, and pleasure, while making use 
                        of the commercial provision of services. 
                    </p>
                </div>
                <div class="col-md-4">
                    <h3>Contact</h3>
                    <p>
                        <i class="fa fa-envelope"></i>
                        <a href="mailto:info@travelsrilanka.lk">
                          info@travelsrilanka.lk
                        </a>
                    </p>
                    <p>
                        <i class="fa fa-phone"></i>
                        <a href="tel: +947123456789">
                          +947123456789
                        </a>
                    </p>
                </div>
                <div class="col-md-4">
                    <h3>Social</h3>
                    <p class="social-links">
                        <a href="facebook.com">
                            <i class="fa fa-facebook"></i>
                        </a>
                        <a href="twitter.com">
                            <i class="fa fa-twitter"></i>
                        </a>
                        <a href="instragram.com">
                            <i class="fa fa-instagram"></i>
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </footer>
</div>
</template>

<script>
export default {
  name: "Footer",
  data () {
    return {
      //
    }
  },
  methods: {
    //
  }

}
</script>

<style scoped>
.footer{
    background-color: #f5f5f5;
    padding: 20px 0;
  margin-top: 50px;
}
.social-links{
  font-size: 50px;
}

</style>

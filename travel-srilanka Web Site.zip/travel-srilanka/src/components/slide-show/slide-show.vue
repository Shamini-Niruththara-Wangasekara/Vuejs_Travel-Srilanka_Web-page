<template>
<div style="height: 600px">
  <transition-group name="fade" tag="div">
    <div v-for="i in [currentIndex]" :key="i">
      <img :src="currentSlide.cover" width="100%" />
      <h2 class="header_title">
        {{currentSlide.title}}
      </h2>
    </div>
  </transition-group>
</div>
</template>

<script>
export default {
  name: "slide-show",
  data(){
    return{
      slides:[
        {
          cover:"https://wallpapercave.com/wp/wp1857977.jpg",
          title:"WELCOME TO SRI LANKA  TRAVEL-SRI LANKA - Slide 1"


        },
        {
          cover: "https://wallpapercave.com/wp/wp1858034.jpg",
          title: "WELCOME TO SRI LANKA  TRAVEL-SRI LANKA - Slide 2"
        },
        {
          cover: "https://wallpapercave.com/wp/wp1857978.jpg",
          title: "WELCOME TO SRI LANKA  TRAVEL-SRI LANKA - Slide 3"
        }
      ],
      timer: null,
      currentIndex: 0
    }},
  methods: {
    startSlide: function() {
      this.timer = setInterval(this.next, 4000);
    },

    next: function() {
      this.currentIndex += 1;
    },
    prev: function() {
      this.currentIndex -= 1;
    }
  },
  computed: {
    currentSlide: function() {
      return this.slides[Math.abs(this.currentIndex) % this.slides.length];
    }
  },
  mounted: function() {
    this.startSlide();
  }
}
</script>

<style scoped>
.header_title {
  font-size: 2em;
  font-weight: bold;
  text-align: center;
  color: #dbf79c;
  position:absolute;
  top: 50%;
  left: 50%;
}
.fade-enter-active,
.fade-leave-active {
  transition: all 0.9s ease;
  overflow: hidden;
  visibility: visible;
  position: absolute;
  width:100%;
  opacity: 1;
}

.fade-enter,
.fade-leave-to {
  visibility: hidden;
  width:100%;
  opacity: 0;
}

img {
  height:600px;
  width:100%
}

.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.7s ease;
  border-radius: 0 4px 4px 0;
  text-decoration: none;
  user-select: none;
}

.next {
  right: 0;
}

.prev {
  left: 0;
}

.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.9);
}

.intro {
  font-family: Arial, Helvetica, sans-serif;
  color: rgb(9, 46, 15);
  font-size: 18px;
}
</style>


<template>
  <div class="row" style="transform: scale(1);" >
    <div class="col">
      <div :id="svgId" class="svg-container"  ></div>
      <p class="des">Select places as you wish to discover</p>
    </div>
  </div>
</template>
<script>
import austriaMap from "./mapData"
import './map.scss'
export default {
  name: "AustriaMap",
  data: function () {
    return {
      svgId: "austriaMap",
      mapAttr: {
        viewBoxWidth: 1300.0,
        viewBoxHeight: 1800,
        imageWidth: 1106,
        imageHeight: 500,
      },
      scale: 0.1,
      svgContainer: null
    }
  },
  props: {
    discrict: {
      type: String,
      default: null
    }
  },
  mounted: function () {
    this.generateVenueMap(null)
  },
  watch: {
    discrict: function (newVal, oldVal) {
      document.getElementsByClassName("svg-container")[0].innerHTML = ""
      this.generateVenueMap(newVal)
    }
  },
  methods: {
    generateVenueMap: function (id) {
      const vue = this;
      const mapData = austriaMap.g.path
      const svgContainer = vue.$svg("austriaMap").size('100%', '100%').viewbox(-200, 0, vue.mapAttr.viewBoxWidth, vue.mapAttr.viewBoxHeight);
      vue.svgContainer = svgContainer;
      mapData.forEach((pathObj) => {
        const className = pathObj["-id"] === id ? " active" : "map-path";
        vue.generatePath(svgContainer, pathObj, className);
      })
    },
    generatePath: function (svgCont, pathObj, className) {
      const vue = this;
      console.log(className)
      const attrs = {
        'stroke': "white",
        'stroke-width': 2,
        'title': pathObj["-title"],
        'map-id': pathObj["-id"],
        'class': className
      };
      const element = svgCont.path(pathObj["-d"]).attr(attrs);
      element.click(function () {
        const mapId = this.node.attributes["map-id"].value;
        const title = this.node.attributes["title"].value;
        vue.$emit("map-clicked", {mapId, title});
      })

    }
  }

}
</script>




<template>
<div class="row mt-5 place_container" >
  <div class="col-auto mt-5" v-for="place in places" v-bind:key="place.id">
    <div class="card" style="width: 18rem;" >
      <img class="card-img-top" :src="place.cover" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">{{place.name}}</h5>
<!--        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>-->
        <a :href="`place/${place.id}`" class="btn btn-primary">view more.</a>
      </div>
    </div>
  </div>

</div>
</template>

<script>
import {PlaceData} from "../DataSet/dataSet";
export default {
  name: "PlaceList",
  props: {
    district: {
      type: String,
    }
  },
  data() {
    return {
      title: "Places",
      places: [...PlaceData]
    };
  },
  watch: {
    district: function(newVal, oldVal) {
      console.log(newVal);
      this.places = PlaceData.filter(place => place.districtCode === newVal);
    }
  },
  computed: {
    placesDataget() {
      if(this.district.length>0) {
        console.log(this.district);
        this.places = PlaceData.filter(place => place.districtCode === this.district);
      }
      this.places = PlaceData;
    }
  },
}
</script>

<style scoped>
.place_container{
  height: 500px;
  overflow-y: auto;
}
.intro {
  font-family: Arial, Helvetica, sans-serif;
  color: rgb(9, 46, 15);
  font-size: 18px;
}
</style>

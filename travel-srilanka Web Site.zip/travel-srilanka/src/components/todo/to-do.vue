<template>
  <div class="row">
    <div class="col">
          <input type="text" v-model="newTitle" ref="title" />
          <button class="btn btn-primary" v-on:click="addTodo">Add Task</button>
    </div>
    <div class="col todo_container">
          <task v-for="todo in todos" v-bind:todo="todo" v-bind:key="todo.id" v-on:removeTask ="removeTask" v-on:markAsComplete="markAsCompleted"></task>
    </div>
  
  </div>
</template>

<script>
import Task from './task'
export default {
  name: 'to-do',
  components: {Task},
  data() {
    return {
      newTitle: ''
    }
  },
  props: {
    todos: {
      type: Array,
      required: true,
      default: []
    }
  },
  methods: {

    removeTask: function (task) {
      this.todos.splice(this.todos.indexOf(task), 1)
    },
    addTodo () {
      const title = this.newTitle
      this.$emit('addTodo', title, "this is description")
    },
    markAsCompleted: function (task) {
      console.log(task)
      this.$emit('markAsCompleted', task.id)
    }

  }
}
</script>

<style scoped>

.todo_container{
  height: 500px;
  overflow-y: auto;
}
</style>


export const PlaceData = [
  {
    id: 1,
    name: "Seema Malaka Temple",
    cover: "https://www.planetware.com/wpimages/2020/01/sri-lanka-best-places-to-visit-colombo.jpg",
    description: "The capital combines modern urban amenities with the country's colorful indigenous and colonial history. As a key stop on the world spice trade routes, Sri Lanka has long held strategic importance for European trading powers. The country has been a colony of Portugal, the Netherlands, and most recently the British, and all these cultures blend with the native culture to form a wonderful hybrid. You can taste these influences in food, see them in architecture and the arts, and you can really feel them in Colombo.\n" +
      "\n" +
      "The city is also filled with museums and other things to see and do that can help connect you with Sri Lankan culture. Colombo sits on the coast, and there's a large green space and beach area right in the heart of the city separating an area called Fort from the Indian Ocean. It's the city's public playground and a fun place to visit, especially on Friday and Saturday nights.",
    brief: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ",
    districtCode: "AT-26",
    districtName: "Colombo",
    images: [{
      url: "https://www.globetrove.com/wp-content/uploads/2018/09/Seema-Malaka.jpg",
      title: "Image 1"
    }, {
      url: "https://www.globetrove.com/wp-content/uploads/2018/09/Beira-Lake.jpg",
      title: "A glimpse of Seema Malaka from the other side of the Beira lake.\n" +
        "\n"
    }, {
      url: "https://www.globetrove.com/wp-content/uploads/2018/09/Buddha-statue-in-Seema-Malaka.jpg",
      title: "A Buddha statue in Seema Malaka."
    }]
  },
  {
    id: 2,
    name: "Lotus Tower",
    cover: "https://media-cdn.tripadvisor.com/media/photo-s/19/57/77/0b/blooming-colombo.jpg",
    description: "One of the coolest places to visit in Colombo is also one of the city's newest attractions. The Colombo Lotus Tower is South Asia's tallest freestanding structure (368 meters/1,168 feet), and a trip to the top rewards visitors with unobstructed views across Colombo and the surrounding cityscape and sea.\n" +
      "\n" +
      "The tower, which houses a lot of telecommunications equipment, has a telecom museum, a shopping mall, a revolving fine dining restaurant, a hotel, and indoor and outdoor observation areas. The tower is also a sight to see from the outside - it's covered in LED lighting and presents seasonal themed lighting displays each night.\n" +
      "\n" +
      "The Lotus Tower, designed to replicate a lotus bulb and flower, simultaneously represents the historic culture of the country and its focus on the future.\n" +
      "\n",
    brief: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ",
    districtCode: "AT-26",
    districtName: "colombo",
    images: [{
      url: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,h_600,q_auto,w_auto/v1/filestore/kmwpt2e6q1n3i7gsabo6lmkqfqbg_1581756612_shutterstock_1444012382.jpg",
      title: "Image 1"
    }, {
      url: "https://i.postimg.cc/BvnZjMfC/shutterstock-1084356770.jpg",
      title: "Image 2"
    }, {
      url: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,q_auto/v1/filestore/ym9qwjjrrxpwcu73aw3vyo760x4j_image.jpg",
      title: "Image 3"
    },{
      url: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,q_auto/v1/filestore/dutqv8711soy7ayz2ea52vz8az7k_image.jpg",
      title: "Image 4"
    },
      {
        url: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,q_auto/v1/filestore/4323au9w8q3ygb0uuviv2ip49k2j_image.jpg",
        title: "Image 5"
      }]
  },
  {
    id: 3,
    name: "Kelaniya Raja Maha Viharaya",
    cover: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,h_600,q_auto,w_auto/v1/filestore/fgdjdlgfjbm1ta79ue4houdshp19_1580890905_DSC_1399.JPG",
    description: "Kelaniya Raja Maha Vihara is a Buddhist temple in Kelaniya, a suburb in the western region of Colombo, Sri Lanka. This temple is both a perfect combination of historical significance and architectural aesthetics. Over the years, this site has come to be associated with the flourishing of Sri Lanka.\n" +
      "\n" +
      "It is often considered that the rise and fall of this temple were highly associated with the rise and fall of Ceylon.This Buddhist temple was developed during the rise of Ceylon and had a lot to offer in terms of the stored artefacts historical figures within it. Apart from being a prominent Buddhist temple, it is also a significant tourist attraction of Sri Lanka.\n" +
      "\n" +
      "Kelaniya Raja Maha Vihara has not only become a popular tourist spot in Sri Lanka but has also developed as an educational institution, especially for students of history and architecture. You would often find schools and colleges conducting excursions here. A lot of research activity is carried out here too. Located on the banks of the Kelani River this temple is often considered to be a site of worship for the popular Ramayana character, Vibhisana.\n" +
      "\n" +
      "Be it the elaborate architecture, or the beauty of the surroundings, this place is sure to keep your eyes fixed to it in terms of the enriching history and beauty. If you are fond of history, architecture and aesthetics, this temple provides for a perfect conglomeration of all these which is sure to be etched in your heart forever.",
    brief: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ",
    districtCode: "AT-26",
    districtName: "colombo",
    images: [{
      url: "https://live.staticflickr.com/4154/5440543518_e56862635f_b.jpg",
      title: "Image 1"
    }, {
      url: "https://live.staticflickr.com/5140/5439887839_a7232d829e_b.jpg",
      title: "Image 2"
    }, {
      url: "https://live.staticflickr.com/492/20450351511_bf412884a2_b.jpg",
      title: "Image 3"
    },

    ]
  },
  {
    id: 4,
    name: "Jaya Sri Maha Bodhi",
    cover: "http://www.touristdirectory.lk/assets/img/article/body/Cities/Anuradhapura/JayaSriMahaBodhi.jpg",
    description: "One of the most sacred relics of the Buddhists in Sri Lanka and respected by Buddhists all over the world, Jaya Sri Maha Bodhi of Anuradhapura, is the oldest living tree in documented history of the world. It is said to be the southern branch from the historical Bodhi tree Sri Maha Bodhi at Bodh Gaya in India under which Lord Buddha attained Enlightenment. It was planted in 288 BCF and is the oldest living human-planted tree in the world with a known planting date. It was brought from Bodh Gaya in India by the Ven Sanghamitta Therini, a sister of Arhant Mahinda who introduced the Teachings of the Buddha to Sri Lanka. The area around the Jaya Sri Maha Bodhi, the Brazen Palace and Ruwanweliseya Dagoba were once probably part of the Great Temple. It has been tended by a continuous succession of guardians for over 2000 years, even during the periods of Indian occupation.",
    brief: "",
    districtCode: "AT-5",
    districtName: "Anuradhapura",
    images: []
  },
  {
    id: 5,
    name: "Abhayagiri Dagoba",
    cover: "http://www.touristdirectory.lk/assets/img/article/body/Cities/Anuradhapura/AbhayagiriDagobaa.jpg",
    description: "Abhayagiri Chetiya is one of the most Sacred Buddhist pilgrimage sites. Historically it was a great monastic centre as well as a royal capital. To the north of the city, encircled by great walls and containing elaborate bathing ponds, carved balustrades and moonstones, stood “Abhayagiri”, one of sixteen such religious units in Anuradhapura and a major Vihara. Surrounding the humped Dagoba, Abhayagiri Vihara was a seat of the Northern Monastery, or Uttara Vihara. Abhayagiri Dagoba was the centrepiece monastery of 5000 monks.",
    brief: "",
    districtCode: "AT-5",
    districtName: "Anuradhapura",
    images: []
  },
  {
    id: 6,
    name: "Thuparamaya ",
    cover: "http://www.touristdirectory.lk/assets/img/article/body/Cities/Anuradhapura/Thuparamaya.jpg",
    description: "Thuparamaya, the oldest Stupa in Sri Lanka built after the introduction of Buddhism to Sri Lanka. Thuparamaya, built by King Devanapiyatissa, enshrines the sacred collar bone relic of the Buddha. This relic, a gift from India, stands testimony to the cordial relations enjoyed by the then ruler of Sri Lanka. The columns around the stupa were a part of the walkway that supported a roof which covered the sacred edifice. Aesthetically, the interior of such a structure must have been the stunning expression of wood engineering and of the most skilful craftsmanship. The edifice’s conical design, unique in the architectural history of the world, continues to be discussed and debated by scholars and scientists.",
    brief: "",
    districtCode: "AT-5",
    districtName: "anuradhapura",
    images: []
  },
  {
    id: 7,
    name: "Ruwanweliseya",
    cover: "http://www.touristdirectory.lk/assets/img/article/body/Cities/Anuradhapura/RuwanwalisayaC.jpg",
    description: "The Ruwanweliseya was built by King Dutugemunu in the 2nd century BCE. Since being restored, the dome is clear and shines white in the sun. S.M. Burrows of the Ceylon Civil Service wrote in 1885, “Its present height is about 150 feet, with a diameter of 379 feet. It is now being restored by the pious contributions of pilgrims, and the zealous efforts of the Chief Priest.",
    brief: "",
    districtCode: "AT-5",
    districtName: "Anuradhapura",
    images: []
  },
  {
    id: 8,
    name: "Aluvihara Rock Cave Temple",
    cover: "http://www.touristdirectory.lk/assets/img/article/body/ReligiousAttractions/AluviharaRockCaveTemple/Aluwiharaya.jpg",
    description: "",
    brief: "",
    districtCode: "AT-1",
    districtName: "Mathale",
    images: []
  },
  {
    id: 9,
    name: "Parakrama Samudra",
    cover: "https://www.news.lk/media/k2/items/cache/a873d75ecea1364aaeedb0f4b379d9b2_L.jpg",
    description: "Parakrama Samudra is a colossal reservoir lying over 5000 acres of land built by King Parakramabahu I in the 12th century. Parakrama Samudra which means 'sea of Parakrama' has been built combining several tanks such as Topa Wewa, Eramudu Wewa, and Dumbutula Wewa. The dam of the reservoir runs 14 km long while standing 40 feet high. Over 20,000 acres of paddy fields are irrigated by this huge ancient reservoir.",
    brief: "",
    districtCode: "AT-3",
    districtName: "Polonnaruwa",
    images: [{
      url: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Parakrama_Samudra_Tank_Polonnaruwa.jpg/800px-Parakrama_Samudra_Tank_Polonnaruwa.jpg",
      title: "Image 1"
    }, {
      url: "https://s3-ap-southeast-1.amazonaws.com/tripazing-prod/large/Parakrama-Samudra1527004753392-470937.jpg",
      title: "Image 2"
    }, {
      url: "http://2.bp.blogspot.com/-jaqc08tvk4E/T_nQhakx_cI/AAAAAAAAHss/IlD5iW15P8E/s1600/IMG_2904-001.JPG",
      title: "Image 3"
    },{
      url: "https://c2.staticflickr.com/4/3053/2717076816_90d463cbc4_z.jpg?zz=1",
      title: "Image 4"
    },
      {
        url: "https://live.staticflickr.com/2603/4203189008_e123f9208b_b.jpg",
        title: "Image 5"
      }

    ]
  },
  {
    id: 10,
    name: "Yala National Park",
    cover: "https://media-cdn.tripadvisor.com/media/attractions-splice-spp-720x480/09/f2/0f/25.jpg",
    description: "Yala National Park (also known as Ruhuna National Park) is located in the south eastern region of Sri Lanka and extends over two provinces of Hambantota district of southern province and Monaragala district in Uva province.",
    brief: "",
    districtCode: "AT-22",
    districtName: "Monaragala",
    images: [{
      url:"https://www.ekhohotels.com/ekhosafari/wp-content/uploads/sites/2/2018/07/Yala-2560X1400.jpg",
      title: "Image 1"
    }, {
      url:"https://www.newsfirst.lk/wp-content/uploads/2017/11/Yala.jpg",
      title: "Image 2"
    }, {
      url:"https://cdn.images.express.co.uk/img/dynamic/128/590x/elephant1-937815.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 11,
    name: "Dambulla Royal cave Temple and Golden",
    cover: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeWTBJMU8Lffq957MUblI3N1K9Liej-Q7weBAl3CkSyidRx7IoCHXdH-FsrvyzDSz5D8_G-CY4QJ_iEK30Ghzj-A",
    description: "Dambulla cave temple also known as the Golden Temple of Dambulla is a World Heritage Site in Sri Lanka, situated in the central part of the country. This site is situated 148 kilometres east of Colombo, 72 kilometres north of Kandy and 43 km north of Matale Dambulla is the largest and best-preserved cave temple complex in Sri Lanka. ",
    brief: "",
    districtCode: "AT-1",
    districtName: "Mathale",
    images: [{
      url: "https://whc.unesco.org/uploads/thumbs/site_0561_0001-1200-630-20151105161136.jpg",
      title: "Image 1"
    }, {
      url: "https://img.traveltriangle.com/blog/wp-content/uploads/2018/10/dambulla-cave-temple-cover-img.jpg",
      title: "Image 2"
    }, {
      url: "https://i2.wp.com/www.p4panorama.com/wp-content/uploads/2015/11/dambulla-cave-temple_srilanka.jpg?resize=1440%2C600",
      title: "Image 3"
    },

    ]
  },{
    id: 12,
    name: "Sri Pada / Adam's Peak",
    cover: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSQVhFH664dzCfNbfid-eeI6-wgUM2-YOydiK9ylBsBp_2GwDq-xGmhvA6kdrlImMGORr35iUghmPMpUdDVpTSQg",
    description: "Adam's Peak is a 2,243 m tall conical mountain located in central Sri Lanka. It is well known for the Sri Pada, sacred footprint, a 1.8 m rock formation near the summit, which in Buddhist tradition is held to be the footprint of the Buddha",
    brief: "",
    districtCode: "AT-17",
    districtName: "Rathnapura",
    images: [{
      url: "https://embassyofsrilankauae.com/wp-content/uploads/2017/04/sripadhaya2017.jpg",
      title: "Image 1"
    }, {
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQR1IjZxNlE84wLk6VzasNch9cwUqWjhUQdBQoHBgW_gldiMOhZ0Hb0kOXrveqmgP2a3AY&usqp=CAU",
      title: "Image 2"
    }, {
      url: "https://www.thingstodosrilanka.com/wp-content/uploads/2020/05/adams-peak-sri-pada.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 13,
    name: "Temple of the Sacred Tooth Relic",
    cover: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTi-XnOBfX75vhDCrPNFeOzPQBjSjwh_fD_WKiBPzPgHoQWXK6Y8wStonaAzG27pLv_MIFMW45cBpjqAlDOFrrwyQ",
    description: "Temple of the Sacred Tooth Relic or Sri Dalada Maligawa; commonly known as the ශ්‍රී දළදා මාළිගාව, is a Buddhist temple in Kandy, Sri Lanka. It is located in the royal palace complex of the former Kingdom of Kandy, which houses the relic of the tooth of the Buddha. ",
    brief: "",
    districtCode: "AT-32",
    districtName: "Maha Nuwara",
    images: [{
      url: "https://images.thrillophilia.com/image/upload/s--ksgeoGpS--/c_fill,g_center,h_450,q_auto,w_753/dpr_1.0,f_auto,fl_strip_profile/v1/images/photos/000/068/650/original/5083535526_75beee8f11_o.jpg.jpg",
      title: "Image 1"
    }, {
      url: "https://www.ceylonexpeditions.com/medias/destination_places/big/106/temple-of-the-sacred-tooth-relic-kandy.jpg",
      title: "Image 2"
    }, {
      url: "https://lp-cms-production.imgix.net/2019-06/b25bd7052083d3b37f232c3c40363774-temple-of-the-sacred-tooth-relic.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 14,
    name: "Udawalawe National Park",
    cover: "https://encrypted-tbn0.gstatic.com/licensed-image?q=tbn:ANd9GcR1QQXbsc8CAg7B49feML0joEC69QiHU4PxRn-hHxB1c3u_vANsKMmIM8b5Av7CViosJowQuiASyoeM5ApUX_OnfA",
    description: "Udawalawe National Park is a national park on the boundary of Sabaragamuwa and Uva Provinces in Sri Lanka. The park was created to provide a sanctuary for wild animals displaced by the construction of the Udawalawe Reservoir on the Walawe River, as well as to protect the catchment of the reservoir. ",
    brief: "",
    districtCode: "AT-22",
    districtName: "Monaragala",
    images: [{
      url: "https://images.thrillophilia.com/image/upload/s--G7tsEBdL--/c_fill,h_600,q_auto,w_975/f_auto,fl_strip_profile/v1/images/photos/000/055/208/original/1558097416_shutterstock_726294346.jpg.jpg?1558097416",
      title: "Image 1"
    }, {
      url: "https://media.tacdn.com/media/attractions-splice-spp-674x446/09/de/b4/21.jpg",
      title: "Image 2"
    }, {
      url: "https://www.srilankabiggamesafaris.com/images/leopard-sighting-at-udawalawe-national-park.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 15,
    name: "Bentota Beach",
    cover: "https://www.holidify.com/images/cmsuploads/compressed/15764564977_ac773086f7_b_20190724102034.jpg",
    description: "The mesmerizing view of the sea will leave you speechless. If you are planning to break the monotony of the routine just try your hands at adventure sports found alongside the palm trees. You should not miss to visit this Sri Lanka tourist place as it is quite popular amongst tourists. ",
    brief: "",
    districtCode:"AT-18",
    districtName: "Galle",
    images: [{
      url: "https://media-cdn.tripadvisor.com/media/photo-s/0c/b5/9e/a4/beauty-at-bentota-beach.jpg",
      title: "Image 1"
    }, {
      url: "https://sri-lanka-and-beyond.com.au/wp-content/uploads/2018/01/Beach-Stays_shutterstock_562419673-2000x1334.jpg",
      title: "Image 2"
    }, {
      url: "https://media-cdn.tripadvisor.com/media/photo-s/1a/e6/40/75/cinnamon-bentota-beach.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 16,
    name: "International Buddhist Museum",
    cover: "https://www.tlc.lk/wp-content/uploads/2017/08/TLClk_Buddhist-Museum-CSP19408498.jpg",
    description: "The International Buddhist Museum is a complete knowledge base and a showcase of the spread of Buddhism throughout Asia. It is one of the famous religious places to visit in Sri Lanka.",
    brief: "",
    districtCode: "AT-32",
    districtName: "kandy",
    images: [{
      url: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Golden_Buddha_and_Buddhist_Museum_at_Dambulla.jpg/800px-Golden_Buddha_and_Buddhist_Museum_at_Dambulla.jpg",
      title: "Image 1"
    }, {
      url: "https://www.farhorizontours.com/sites/default/files/styles/teaser_image/public/dropped/2019-04/dreamstimemaximum_89288889-dambulla-buddha-statues-cave-golden-temple-s.jpg?itok=1k1SdvaF",
      title: "Image 2"
    }, {
      url: "https://www.watchinglanka.com/wp-content/uploads/2020/10/thumbnail-min-14-768x282.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 17,
    name: "Sorabora Lake",
    cover: "https://images.thrillophilia.com/image/upload/s--5PIji4nK--/c_fill,g_center,h_450,q_auto,w_753/dpr_1.0,f_auto,fl_strip_profile/v1/images/photos/000/069/574/original/1516358887_Slider4.jpg.jpg",
    description: "Sorabora Wewa is an ancient reservoir in Mahiyangana, Badulla District Sri Lanka. It is thought to have been constructed during the reign of King Dutugemunu by a giant named Bulatha. In the ancient past, this tank was known as the 'Sea of Bintenna'.",
    brief: "",
    districtCode: "AT-21",
    districtName: "Mahiyanganaya",
    images: [{
      url: "https://www.lakpura.com/images/LK94007772-03-E-360-250.JPG",
      title: "Image 1"
    }, {
      url: "https://media-cdn.tripadvisor.com/media/photo-s/0f/35/e5/4d/sorabora-lake-boat-riding.jpg",
      title: "Image 2"
    }, {
      url: "https://thumbs.dreamstime.com/b/one-most-beautiful-lake-sri-lanka-sorabora-wewa-beautiful-mountains-beautiful-lake-veiw-sri-lanka-147309665.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 18,
    name: "Pinnewala Elephant Orphanage",
    cover: "https://images.thrillophilia.com/image/upload/s--TAN6d9_P--/c_fill,g_center,h_450,q_auto,w_753/dpr_1.0,f_auto,fl_strip_profile/v1/images/photos/000/069/430/original/1516357073_7_34_20%283%29.jpg.jpg",
    description: "Peradeniya Gardens is a spacious 147 acre of natural extravaganza consisting of more than 4000 species of plants, and 10,000 varied kinds of trees, incidentally serves as the largest garden in Sri Lanka and is one of the best places to visit in Sri Lanka. ",
    brief: "",
    districtCode: "AT-23",
    districtName: "Kegalle",
    images: [{
      url: "https://overatours.com/wp-content/uploads/2019/05/127-1024x683.jpg",
      title: "Image 1"
    }, {
      url: "https://overatours.com/wp-content/uploads/2019/05/130-1024x683.jpg",
      title: "Image 2"
    }, {
      url: "https://i.pinimg.com/originals/ed/2f/3b/ed2f3ba76fa07de533a0591f7501fbb4.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 19,
    name: "Horton Plains National Park",
    cover: "https://images.thrillophilia.com/image/upload/s--fSrwfU26--/c_fill,g_center,h_450,q_auto,w_753/dpr_1.0,f_auto,fl_strip_profile/v1/images/photos/000/069/446/original/1612161000_shutterstock_1246568662.jpg.jpg",
    description: "Horton National Park is a ‘food for the soul’ kind of mesmerizing locale. The park is perched in the shadows of the country’s 2nd and 3rd highest mountains, Kirigalpota and Totapola. The place is also termed as world’s end due to its undaunting mysterious views of waterfalls, misted lakes and earthy species of flora and fauna. The national park is actually a plateau and is 2000m high. It is better to start early in the morning to witness this heavenly place.",
    brief: "",
    districtCode: "AT-31",
    districtName: "Nuwara Eliya",
    images: [{
      url: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,h_600,q_auto,w_auto/v1/filestore/s8285xvu203aclwqe1ksjuvm5kfd_1583568975_fi.jpg",
      title: "Image 1"
    }, {
      url: "https://travellerhints.com/wp-content/uploads/2016/03/beautiful-worlds-end.jpg",
      title: "Image 2"
    }, {
      url: "https://images.thrillophilia.com/image/upload/s--fSrwfU26--/c_fill,g_center,h_450,q_auto,w_753/dpr_1.0,f_auto,fl_strip_profile/v1/images/photos/000/069/446/original/1612161000_shutterstock_1246568662.jpg.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 20,
    name: "Dehiwala Zoo",
    cover:  "https://cdn.hirunews.lk/Data/News_Images/202112/1639206935_7665088_hirunews.jpg",
    description: "Dehiwala Zoo or the National Zoological Gardens of Sri Lanka was set up during 1936 with the sole ambition of providing ultimate protection to a wide range of wild animals and birds. ",
    brief: "",
    districtCode: "AT-26",
    districtName: "colombo",
    images: [{
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMJpAjynjzvAYMxl_YVAeut_Oe0YrQDu-N6A&usqp=CAU",
      title: "Image 1"
    }, {
      url: "https://www.attractionsinsrilanka.com/wp-content/uploads/2019/08/National-Zoological-Gardens-of-Sri-Lanka.jpg",
      title: "Image 2"
    }, {
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMAhOzlo43cq9wpdAMckC7XK7Gz-0NG7SRpg&usqp=CAU",
      title: "Image 3"
    },

    ]
  },{
    id: 21,
    name: "Bambarakanda Falls",
    cover: "https://www.lakpura.com/images/LK94009951-04-E.JPG",
    description: "Mark it on your bucket list to visit this one of the most tranquil place while you are in Sri Lanka. With a sheer drop of waterfall from a height of 263 meters Bambarakanda Falls is one of the highest waterfalls in Sri Lanka",
    brief: "",
    districtCode: "AT-21",
    districtName: "Badulla",
    images: [{
      url: "https://images.thrillophilia.com/image/upload/s--oxzBJ8iW--/c_fill,h_450,q_auto,w_400/f_auto,fl_strip_profile/v1/images/photos/000/178/965/original/1597144648_shutterstock_160864763.jpg.jpg?1597144648",
      title: "Image 1"
    }, {
      url: "https://api-blog.antiquitysl.com/wp-content/uploads/2019/08/bambarakanda-overview2.jpg",
      title: "Image 2"
    }, {
      url: "https://www.srilankanexpeditions.lk/tour_img/1487835854IMG_9912.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 22,
    name: "Gangaramaya Temple",
    cover: "https://c8.alamy.com/comp/DGMR73/sri-lanka-colombo-gangaramaya-temple-and-buddha-statue-DGMR73.jpg",
    description: "Gangaramaya Temple is not only one of the most beautiful but also one of the most iconic Buddhist temples in Sri Lanka.",
    brief: "",
    districtCode: "AT-26",
    districtName: "Colombo",
    images: [{
      url: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,h_600,q_auto,w_auto/v1/filestore/eroknzeg63hrum6xty5qww1sf154_1580210450_shutterstock_327595163.jpg",
      title: "Image 1"
    }, {
      url: "https://www.trawell.in/admin/images/upload/151111298Srilanka_colombo_gangaramaya.jpg",
      title: "Image 2"
    }, {
      url: "https://www.thekingsburyhotel.com/blog/wp-content/uploads/sites/3/2018/10/Gangaramaya-temple-in-Sri-Lanka-1024x576.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 23,
    name: "National Museum of Colombo",
    cover: "https://img.traveltriangle.com/blog/wp-content/uploads/2018/10/national-musuem-of-colombo-cover-img.jpg",
    description: "If you are a history lover and have a keen eye for architecture, the National Museum is probably one of the first few places to visit in Colombo.",
    brief: "",
    districtCode: "AT-26",
    districtName: "Colombo",
    images: [{
      url: "https://lp-cms-production.imgix.net/2019-06/1e6983e6b69c76ef0eecf95b97499da4-national-museum.jpg",
      title: "Image 1"
    }, {
      url: "https://media.timeout.com/images/101903337/630/472/image.jpg",
      title: "Image 2"
    }, {
      url: "https://srilankatravelhub.com/images/experiences/national-museum-colombo.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 24,
    name: "Galle Fort Lighthouse ",
    cover: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,dpr_1.0,f_auto,fl_progressive.strip_profile,g_center,h_450,q_auto,w_753/v1/filestore/aobaf1yw2mrowt8a50rvhq5jhavm_1582217692_galle_lighthouse.jpg",
    description: "Also renowned as Pointe de Galle Light, Galle Lighthouse is a prominent tourist attraction of Galle. Situated on the shores of Galle, the lighthouse makes a postcard-perfect scenario against the emerald waves hitting the fine beige sands of Galle. Also, it is situated inside the architectural marvel of the city, Galle Fort, which defines its scenic beauty further.",
    brief: "",
    districtCode: "AT-18",
    districtName: "Galle",
    images: [{
      url: "https://afar-production.imgix.net/uploads/images/post_images/images/tBSLrE5ywQ/original_257f690912cb23806c7ade7b9b406cd9.jpg?1466192800?ixlib=rails-0.3.0&auto=format%2Ccompress&crop=entropy&fit=crop&h=719&q=80&w=954",
      title: "Image 1"
    }, {
      url: "https://saltinourhair.com/wp-content/uploads/2016/11/galle-dutch-fort-sri-lanka-lighthouse.jpg?x64612",
      title: "Image 2"
    }, {
      url: "https://img.traveltriangle.com/blog/wp-content/uploads/2018/06/shutterstock_397314796.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 25,
    name: "Koggala Beach",
    cover: "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,dpr_1.0,f_auto,fl_progressive.strip_profile,g_center,h_450,q_auto,w_753/v1/filestore/3tb847bwmsor7yin1f5b733chvig_1580293311_shutterstock_1503294719.jpg",
    description: "",
    brief: "",
    districtCode: "AT-18",
    districtName: "Galle",
    images: [{
      url: "https://cf.bstatic.com/xdata/images/hotel/max1280x900/120196564.jpg?k=31c2ef583d757cacc7cbdbbdeb24647384594e1f38feb3b7d8418bdd67706c28&o=&hp=1",
      title: "Image 1"
    }, {
      url: "https://ep01.epimg.net/elviajero/imagenes/2016/12/12/album/1481554278_843799_1481560076_album_normal.jpg",
      title: "Image 2"
    }, {
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDpM3nN7ET2yuGbS0tUAwV790yxt86MhS6IRKPHs0wlh9Mt6Rge4NT6nF74nMQWfRYSrk&usqp=CAU",
      title: "Image 3"
    },

    ]
  },{
    id: 26,
    name: "Ella Rock ",
    cover: "https://www.visitella.com/img/gallery/gallery_main/22/1.png",
    description: "Ella is popular for its lush greenery and the cool and collected environment amongst the people. Ella Rock is a popular hiking and camping destination and it is a delight to witness spectacular views with haze and clouds surrounding the area.",
    brief: "",
    districtCode: "AT-21",
    districtName: "Badulla",
    images: [{
      url:  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDij2KmYPm7l3pXs20SE1Ixrt-NmA5OLnXU5exh0wx-RnLDv7x11ZZ_z1Oy4hqjHkQctE&usqp=CAU",
      title: "Image 1"
    }, {
      url: "https://image.shutterstock.com/image-photo/fantastic-view-ella-rock-mountain-260nw-1870779526.jpg",
      title: "Image 2"
    }, {
      url: "https://www.lovidhu.com/uploads/posts-seo/2021/03/ella-rock-ella-sri-lanka.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 27,
    name: "Kande Vihara",
    cover: "https://srilankatravelnotes.com/KALUTHARA/KANDEVIHARAYA/images/KandeViharaya1.JPG",
    description: "Kande Vihara is the Kalutara district's largest Buddhist temple. The name of the temple typically means 'Mountain Temple' and was named this because it was built close to Aluthgama town on the crest of a hill. It is also known to be an officially recognized Archaeological Site of Sri Lanka.",
    brief: "",
    districtCode: "AT-28",
    districtName: "Kluthara",
    images: [{
      url: "https://overatours.com/wp-content/uploads/2020/07/Untitled-4.png",
      title: "Image 1"
    }, {
      url: "https://overatours.com/wp-content/uploads/2020/07/Untitled-9.jpg",
      title: "Image 2"
    }, {
      url: "https://srilankafinder.com/wp-content/uploads/2017/12/Kande-Viharaya-700x500.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 28,
    name: "Moragalla Beach",
    cover: "https://images.thrillophilia.com/image/upload/s--H7qKgWHU--/c_fill,g_center,h_450,q_auto,w_753/dpr_1.0,f_auto,fl_strip_profile/v1/images/photos/000/367/676/original/1614253420_shutterstock_697308214.jpg.jpg",
    description: "Moragalla Beach is a paradise for beach lovers, especially for anyone who is looking for a deserted beach trip, as it is mostly peaceful and not noisy at all. Owing to the submerged coral reef that sits not far from the coastline, the sea surrounding Moragalla is very shallow.",
    brief: "",
    districtCode: "AT-28",
    districtName: "Kaluthara",
    images: [{
      url: "https://www.lakpura.com/images/LK94009784-02-E-360-250.JPG",
      title: "Image 1"
    }, {
      url: "https://www.lakpura.com/images/LK94009784-01-E-360-250.JPG",
      title: "Image 2"
    }, {
      url: "https://www.lakpura.com/images/LK94009784-03-E-360-250.JPG",
      title: "Image 3"
    },

    ]
  },{
    id: 29,
    name: "Mirissa Beach",
    cover: "https://images.squarespace-cdn.com/content/v1/596b2969d2b85786e6892853/1531738844396-H040L4I7S80ZGQV196K4/DJI_0780.jpg?format=1500w",
    description: "Mirissa is a tiny village on Sri Lanka's south shore, situated in the Southern Province of Matara District. It is the south coast's largest fishing port and is popular for its tuna, mullet, snapper, and butterfish. If you'd like to experience a mesmerizing sunset dinner with beautiful scenic views, then Mirissa beach is the place to be at.",
    brief: "",
    districtCode: "AT-20",
    districtName: "Mathara",
    images: [{
      url: "https://pix10.agoda.net/city/512866/512866-7x3.jpg?s=1920x",
      title: "Image 1"
    }, {
      url: "https://destinationlesstravel.com/wp-content/uploads/2019/04/DSC_8786-1024x684.jpg",
      title: "Image 2"
    }, {
      url: "https://img.traveltriangle.com/blog/wp-content/uploads/2019/06/Mirissa-cover_24th-Mar.jpg",
      title: "Image 3"
    },

    ]
  },{
    id: 30,
    name: "Guruge Nature Park",
    cover: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/04/b0/11/62/tree-house.jpg?w=1200&h=-1&s=1",
    description: "Guruge park is the first theme park in Sri Lanka. There is a Mayan water park in it. Children are able to enjoy a lot in this place. Apart from that, it consists of places such as birds and animals park,  Jurassic Park, ostrich which are available for children to view.",
    brief: "",
    districtCode: "AT-27",
    districtName: "cGampaha",
    images: [{
      url: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/04/b0/11/9d/walk-way.jpg?w=1200&h=-1&s=1",
      title: "Image 1"
    }, {
      url: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/10/4b/3f/eb/mayan-water-park-entrance.jpg?w=1000&h=-1&s=1",
      title: "Image 2"
    }, {
      url: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/04/95/b9/a2/the-only-board-throughout.jpg?w=500&h=-1&s=1",
      title: "Image 3"
    },

    ]
  },
]

